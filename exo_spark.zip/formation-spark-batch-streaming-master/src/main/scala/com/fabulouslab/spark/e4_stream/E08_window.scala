package com.fabulouslab.spark.e04_stream

import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions.{from_json, window}
import org.apache.spark.sql.types.{LongType, StringType, StructField, StructType}

object E08_window {

    def main(args: Array[String]) {

      /**
        *   - En utilisant le fonction de windowing, calculer le nombre de page consulter par user chaque minute,
        *   pour les 10 dernières minutes,
        * */

    }

  }
